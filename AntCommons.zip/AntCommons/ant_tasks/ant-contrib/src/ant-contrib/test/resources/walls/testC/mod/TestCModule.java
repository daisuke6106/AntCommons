
package mod;

import mod.modA.TestCModuleA;
import mod.modB.TestCModuleB;

public class TestCModule
{
    private TestCModuleA temp1;
    private TestCModuleB temp2;
};