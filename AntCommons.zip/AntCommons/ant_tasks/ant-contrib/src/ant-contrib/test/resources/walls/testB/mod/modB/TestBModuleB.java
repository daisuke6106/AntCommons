
package mod.modB;

import mod.modA.TestBModuleA;

public class TestBModuleB
{
    private TestBModuleA temp;
};